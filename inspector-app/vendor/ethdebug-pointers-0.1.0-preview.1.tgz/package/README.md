# @ethdebug/pointers

_This NPM package contains a reference implementation for dereferencing
**ethdebug/format**
[pointers](https://ethdebug.github.io/format/spec/pointer/overview)._

## TypeScript

This package uses `package.json` `imports` for internal modules.
Consumers must use `moduleResolution` `node16`, `nodenext`, or
`bundler`. The legacy `node10` resolution is not supported.
